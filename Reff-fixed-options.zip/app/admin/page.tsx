"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Calendar, Clock, LogOut, MapPin, Plus, Users } from "lucide-react";
import {
  deleteMatch,
  getMatches,
  initializeDemoStore,
  isoToDisplayDate,
  type Match,
  type MatchStatus,
} from "@/lib/demo-store";

function getStatusLabel(status: MatchStatus) {
  if (status === "open") return "Otevřeno";
  if (status === "full") return "Obsazeno";
  return "Potvrzeno";
}

function getStatusClasses(status: MatchStatus) {
  if (status === "open") return "bg-amber-100 text-amber-800 ring-amber-200";
  if (status === "full") return "bg-slate-200 text-slate-700 ring-slate-300";
  return "bg-emerald-100 text-emerald-800 ring-emerald-200";
}

export default function AdminPage() {
  const [adminName, setAdminName] = useState("Administrátor");
  const [matches, setMatches] = useState<Match[]>([]);

  const loadMatches = () => {
    setMatches(getMatches());
  };

  useEffect(() => {
    const role = localStorage.getItem("demo-role");
    const storedName = localStorage.getItem("demo-user-name");

    if (!role) {
      window.location.href = "/login";
      return;
    }

    if (role !== "admin") {
      window.location.href = "/zapasy";
      return;
    }

    initializeDemoStore();

    if (storedName) {
      setAdminName(storedName);
    }

    loadMatches();
  }, []);

  const summary = useMemo(() => {
    return {
      total: matches.length,
      open: matches.filter((item) => item.status === "open").length,
      confirmed: matches.filter((item) => item.status === "confirmed").length,
    };
  }, [matches]);

  const handleDelete = (id: string) => {
    const confirmed = window.confirm("Opravdu chcete tento zápas smazat?");
    if (!confirmed) return;

    deleteMatch(id);
    loadMatches();
  };

  const handleLogout = () => {
    localStorage.removeItem("demo-role");
    localStorage.removeItem("demo-user-name");
    localStorage.removeItem("demo-identifier");
    window.location.href = "/login";
  };

  return (
    <main className="min-h-screen bg-slate-100 pb-24">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div>
            <div className="text-lg font-bold text-slate-900">Administrace</div>
            <div className="text-sm text-slate-500">{adminName}</div>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Odhlásit
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-4">
        <div className="mb-4 grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-white p-3 text-center shadow-sm ring-1 ring-slate-200">
            <div className="text-2xl font-bold text-slate-900">{summary.total}</div>
            <div className="text-xs text-slate-500">Všechny</div>
          </div>

          <div className="rounded-2xl bg-white p-3 text-center shadow-sm ring-1 ring-slate-200">
            <div className="text-2xl font-bold text-amber-700">{summary.open}</div>
            <div className="text-xs text-slate-500">Otevřené</div>
          </div>

          <div className="rounded-2xl bg-white p-3 text-center shadow-sm ring-1 ring-slate-200">
            <div className="text-2xl font-bold text-emerald-700">{summary.confirmed}</div>
            <div className="text-xs text-slate-500">Potvrzené</div>
          </div>
        </div>

        <div className="mb-4">
          <Link
            href="/admin/zapasy/novy"
            className="flex h-12 w-full items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800"
          >
            <Plus className="mr-2 h-4 w-4" />
            Přidat zápas
          </Link>
        </div>

        <div className="mb-4">
          <Link
            href="/admin/rozhodci"
            className="flex h-12 w-full items-center justify-center rounded-xl border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-900 transition hover:bg-slate-50"
          >
            Přehled rozhodčích
          </Link>
        </div>

        <div className="space-y-4">
          {matches.map((match) => (
            <article
              key={match.id}
              className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200"
            >
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">
                    {match.home} – {match.away}
                  </h2>
                  <p className="text-sm text-slate-500">{match.competition}</p>
                </div>

                <span
                  className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ring-1 ${getStatusClasses(
                    match.status
                  )}`}
                >
                  {getStatusLabel(match.status)}
                </span>
              </div>

              <div className="space-y-2 text-sm text-slate-700">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-slate-500" />
                  <span>{isoToDisplayDate(match.date)}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-slate-500" />
                  <span>{match.time}</span>
                </div>

                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-slate-500" />
                  <span>{match.location}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-slate-500" />
                  <span>
                    Přihlášeno: {match.applicants} / Potřeba: {match.neededRefs}
                  </span>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-2">
                <Link
                  href={`/admin/zapasy/${match.id}/prihlasky`}
                  className="flex h-11 items-center justify-center rounded-xl bg-slate-900 px-3 text-xs font-semibold text-white transition hover:bg-slate-800"
                >
                  Přihlášky
                </Link>

                <Link
                  href={`/admin/zapasy/${match.id}`}
                  className="flex h-11 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-xs font-semibold text-slate-900 transition hover:bg-slate-50"
                >
                  Upravit
                </Link>

                <button
                  type="button"
                  onClick={() => handleDelete(match.id)}
                  className="flex h-11 items-center justify-center rounded-xl border border-rose-300 bg-white px-3 text-xs font-semibold text-rose-700 transition hover:bg-rose-50"
                >
                  Smazat
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto grid max-w-md grid-cols-4 gap-2 px-3 py-3 text-center text-xs font-medium text-slate-600">
          <Link href="/admin" className="rounded-xl bg-slate-900 px-3 py-2 text-white">
            Admin
          </Link>
          <Link href="/admin" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Zápasy
          </Link>
          <Link href="/delegace" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Delegace
          </Link>
          <Link href="/profil" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Profil
          </Link>
        </div>
      </nav>
    </main>
  );
}