"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Calendar, Clock, LogOut, MapPin, XCircle } from "lucide-react";
import {
  cancelApplication,
  getApplications,
  getMatches,
  initializeDemoStore,
  isoToDisplayDate,
  type Application,
  type ApplicationStatus,
  type Match,
} from "@/lib/demo-store";

function getStatusLabel(status: ApplicationStatus) {
  if (status === "sent") return "Odesláno";
  if (status === "approved") return "Potvrzeno";
  return "Odmítnuto";
}

function getStatusClasses(status: ApplicationStatus) {
  if (status === "sent") return "bg-amber-100 text-amber-800 ring-amber-200";
  if (status === "approved") return "bg-emerald-100 text-emerald-800 ring-emerald-200";
  return "bg-rose-100 text-rose-800 ring-rose-200";
}

export default function PrihlaskyPage() {
  const [userName, setUserName] = useState("Jan Novák");
  const [applications, setApplications] = useState<Application[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);

  const loadData = () => {
    setApplications(getApplications());
    setMatches(getMatches());
  };

  useEffect(() => {
    const role = localStorage.getItem("demo-role");
    const storedName = localStorage.getItem("demo-user-name");

    if (!role) {
      window.location.href = "/login";
      return;
    }

    if (role !== "referee") {
      window.location.href = "/admin";
      return;
    }

    initializeDemoStore();

    if (storedName) {
      setUserName(storedName);
    }

    loadData();
  }, []);

  const myApplications = useMemo(() => {
    return applications.filter((app) => app.refereeName === userName);
  }, [applications, userName]);

  const handleCancel = (applicationId: string) => {
    cancelApplication(applicationId);
    loadData();
  };

  const handleLogout = () => {
    localStorage.removeItem("demo-role");
    localStorage.removeItem("demo-user-name");
    localStorage.removeItem("demo-identifier");
    window.location.href = "/login";
  };

  return (
    <main className="min-h-screen bg-slate-100 pb-24">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div>
            <div className="text-lg font-bold text-slate-900">Moje přihlášky</div>
            <div className="text-sm text-slate-500">Rozhodčí: {userName}</div>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Odhlásit
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-4">
        <div className="space-y-4">
          {myApplications.length === 0 ? (
            <div className="rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
              <div className="text-lg font-semibold text-slate-900">Žádné přihlášky</div>
              <p className="mt-2 text-sm text-slate-500">Zatím nemáte žádné aktivní přihlášky.</p>
            </div>
          ) : (
            myApplications.map((app) => {
              const match = matches.find((item) => item.id === app.matchId);
              if (!match) return null;

              return (
                <article
                  key={app.id}
                  className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">
                        {match.home} – {match.away}
                      </h2>
                      <p className="text-sm text-slate-500">{match.competition}</p>
                    </div>

                    <span
                      className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ring-1 ${getStatusClasses(
                        app.status
                      )}`}
                    >
                      {getStatusLabel(app.status)}
                    </span>
                  </div>

                  <div className="space-y-2 text-sm text-slate-700">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-slate-500" />
                      <span>{isoToDisplayDate(match.date)}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-slate-500" />
                      <span>{match.time}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-slate-500" />
                      <span>{match.location}</span>
                    </div>

                    <div className="text-sm text-slate-500">Čas přihlášení: {app.appliedAt}</div>
                  </div>

                  {app.status === "sent" ? (
                    <div className="mt-4">
                      <button
                        type="button"
                        onClick={() => handleCancel(app.id)}
                        className="flex h-12 w-full items-center justify-center rounded-xl border border-rose-300 bg-white px-4 text-sm font-semibold text-rose-700 transition hover:bg-rose-50"
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Zrušit přihlášku
                      </button>
                    </div>
                  ) : null}
                </article>
              );
            })
          )}
        </div>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto grid max-w-md grid-cols-4 gap-2 px-3 py-3 text-center text-xs font-medium text-slate-600">
          <Link href="/zapasy" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Zápasy
          </Link>
          <Link href="/prihlasky" className="rounded-xl bg-slate-900 px-3 py-2 text-white">
            Přihlášky
          </Link>
          <Link href="/delegace" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Delegace
          </Link>
          <Link href="/profil" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Profil
          </Link>
        </div>
      </nav>
    </main>
  );
}