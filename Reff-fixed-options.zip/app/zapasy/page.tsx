"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Calendar, Clock, LogOut, MapPin, Search, Users } from "lucide-react";
import {
  applyToMatch,
  getMatches,
  initializeDemoStore,
  isoToDisplayDate,
  type Match,
  type MatchStatus,
} from "@/lib/demo-store";

function getStatusLabel(status: MatchStatus) {
  if (status === "open") return "Otevřeno";
  if (status === "full") return "Obsazeno";
  return "Potvrzeno";
}

function getStatusClasses(status: MatchStatus) {
  if (status === "open") return "bg-amber-100 text-amber-800 ring-amber-200";
  if (status === "full") return "bg-slate-200 text-slate-700 ring-slate-300";
  return "bg-emerald-100 text-emerald-800 ring-emerald-200";
}

export default function ZapasyPage() {
  const [search, setSearch] = useState("");
  const [userName, setUserName] = useState("Jan Novák");
  const [matches, setMatches] = useState<Match[]>([]);

  const loadMatches = () => {
    setMatches(getMatches());
  };

  useEffect(() => {
    const storedName = localStorage.getItem("demo-user-name");
    const role = localStorage.getItem("demo-role");

    if (!role) {
      window.location.href = "/login";
      return;
    }

    if (role !== "referee") {
      window.location.href = "/admin";
      return;
    }

    initializeDemoStore();

    if (storedName) {
      setUserName(storedName);
    }

    loadMatches();
  }, []);

  const filteredMatches = useMemo(() => {
    const value = search.trim().toLowerCase();
    if (!value) return matches;

    return matches.filter((match) => {
      const text =
        `${match.home} ${match.away} ${match.competition} ${match.location} ${match.date}`.toLowerCase();

      return text.includes(value);
    });
  }, [matches, search]);

  const handleApply = (matchId: string) => {
    applyToMatch(matchId, userName);
    loadMatches();
  };

  const handleLogout = () => {
    localStorage.removeItem("demo-role");
    localStorage.removeItem("demo-user-name");
    localStorage.removeItem("demo-identifier");
    window.location.href = "/login";
  };

  return (
    <main className="min-h-screen bg-slate-100 pb-24">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div>
            <div className="text-lg font-bold text-slate-900">Zápasy</div>
            <div className="text-sm text-slate-500">Přihlášený: {userName}</div>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Odhlásit
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-4">
        <div className="mb-4 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-200">
          <label htmlFor="search" className="mb-2 block text-sm font-medium text-slate-700">
            Hledat zápas
          </label>

          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              id="search"
              type="text"
              placeholder="Tým, soutěž, místo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-11 w-full rounded-xl border border-slate-300 bg-white pl-10 pr-4 text-base outline-none transition focus:border-slate-500 focus:ring-2 focus:ring-slate-200"
            />
          </div>
        </div>

        <div className="space-y-4">
          {filteredMatches.map((match) => {
            const disabled = match.status !== "open";

            return (
              <article
                key={match.id}
                className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200"
              >
                <div className="mb-3 flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">
                      {match.home} – {match.away}
                    </h2>
                    <p className="text-sm text-slate-500">{match.competition}</p>
                  </div>

                  <span
                    className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ring-1 ${getStatusClasses(
                      match.status
                    )}`}
                  >
                    {getStatusLabel(match.status)}
                  </span>
                </div>

                <div className="space-y-2 text-sm text-slate-700">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-slate-500" />
                    <span>{isoToDisplayDate(match.date)}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-slate-500" />
                    <span>{match.time}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-slate-500" />
                    <span>{match.location}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-slate-500" />
                    <span>
                      Přihlášeno: {match.applicants} / Potřeba: {match.neededRefs}
                    </span>
                  </div>
                </div>

                <div className="mt-4">
                  <button
                    type="button"
                    disabled={disabled}
                    onClick={() => handleApply(match.id)}
                    className="h-12 w-full rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-600"
                  >
                    {match.status === "open" ? "Přihlásit se" : "Nelze se přihlásit"}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto grid max-w-md grid-cols-4 gap-2 px-3 py-3 text-center text-xs font-medium text-slate-600">
          <Link href="/zapasy" className="rounded-xl bg-slate-900 px-3 py-2 text-white">
            Zápasy
          </Link>
          <Link href="/prihlasky" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Přihlášky
          </Link>
          <Link href="/delegace" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Delegace
          </Link>
          <Link href="/profil" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Profil
          </Link>
        </div>
      </nav>
    </main>
  );
}