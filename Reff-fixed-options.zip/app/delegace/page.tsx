"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Calendar, Clock, LogOut, MapPin, Share2 } from "lucide-react";
import {
  getDelegations,
  initializeDemoStore,
  isoToDisplayDate,
  type Delegation,
  type UserRole,
} from "@/lib/demo-store";

export default function DelegacePage() {
  const [role, setRole] = useState<UserRole | null>(null);
  const [userName, setUserName] = useState("Jan Novák");
  const [delegations, setDelegations] = useState<Delegation[]>([]);

  const loadDelegations = () => {
    setDelegations(getDelegations());
  };

  useEffect(() => {
    const storedRole = localStorage.getItem("demo-role") as UserRole | null;
    const storedName = localStorage.getItem("demo-user-name");

    if (!storedRole) {
      window.location.href = "/login";
      return;
    }

    initializeDemoStore();
    setRole(storedRole);

    if (storedName) {
      setUserName(storedName);
    }

    loadDelegations();
  }, []);

  const visibleDelegations = useMemo(() => {
    if (role === "admin") return delegations;

    return delegations.filter(
      (item) => item.mainReferee === userName || item.assistants.includes(userName)
    );
  }, [delegations, role, userName]);

  const handleShare = () => {
    if (visibleDelegations.length === 0) return;

    const text = visibleDelegations
      .map(
        (item) =>
          `Delegace rozhodčích — ${isoToDisplayDate(item.date)}\n${item.time} ${item.home} – ${item.away}\nMísto: ${item.location}\nHlavní rozhodčí: ${item.mainReferee}\nAsistenti: ${item.assistants.join(
            ", "
          )}`
      )
      .join("\n\n");

    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  const handleLogout = () => {
    localStorage.removeItem("demo-role");
    localStorage.removeItem("demo-user-name");
    localStorage.removeItem("demo-identifier");
    window.location.href = "/login";
  };

  return (
    <main className="min-h-screen bg-slate-100 pb-24">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div>
            <div className="text-lg font-bold text-slate-900">Potvrzené delegace</div>
            <div className="text-sm text-slate-500">
              {role === "admin" ? "Administrátor" : `Rozhodčí: ${userName}`}
            </div>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Odhlásit
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-4">
        <div className="mb-4">
          <button
            type="button"
            onClick={handleShare}
            disabled={visibleDelegations.length === 0}
            className="flex h-12 w-full items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-600"
          >
            <Share2 className="mr-2 h-4 w-4" />
            Sdílet přes WhatsApp
          </button>
        </div>

        <div className="space-y-4">
          {visibleDelegations.length === 0 ? (
            <div className="rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
              <div className="text-lg font-semibold text-slate-900">Žádné delegace</div>
              <p className="mt-2 text-sm text-slate-500">
                Zatím nemáte žádné potvrzené delegace.
              </p>
            </div>
          ) : (
            visibleDelegations.map((item) => (
              <article
                key={item.id}
                className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200"
              >
                <div className="mb-3 flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">
                      {item.home} – {item.away}
                    </h2>
                    <p className="text-sm text-slate-500">{item.competition}</p>
                  </div>

                  <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800 ring-1 ring-emerald-200">
                    Potvrzeno
                  </span>
                </div>

                <div className="space-y-2 text-sm text-slate-700">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-slate-500" />
                    <span>{isoToDisplayDate(item.date)}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-slate-500" />
                    <span>{item.time}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-slate-500" />
                    <span>{item.location}</span>
                  </div>
                </div>

                <div className="mt-4 space-y-2 rounded-2xl bg-slate-50 p-3 text-sm text-slate-700">
                  <div>
                    <span className="font-semibold">Hlavní rozhodčí:</span> {item.mainReferee}
                  </div>
                  <div>
                    <span className="font-semibold">Asistenti:</span>{" "}
                    {item.assistants.length > 0 ? item.assistants.join(", ") : "—"}
                  </div>
                </div>
              </article>
            ))
          )}
        </div>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto grid max-w-md grid-cols-4 gap-2 px-3 py-3 text-center text-xs font-medium text-slate-600">
          <Link
            href={role === "admin" ? "/admin" : "/zapasy"}
            className="rounded-xl px-3 py-2 hover:bg-slate-100"
          >
            Zápasy
          </Link>
          <Link
            href={role === "admin" ? "/admin" : "/prihlasky"}
            className="rounded-xl px-3 py-2 hover:bg-slate-100"
          >
            {role === "admin" ? "Admin" : "Přihlášky"}
          </Link>
          <Link href="/delegace" className="rounded-xl bg-slate-900 px-3 py-2 text-white">
            Delegace
          </Link>
          <Link href="/profil" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            Profil
          </Link>
        </div>
      </nav>
    </main>
  );
}