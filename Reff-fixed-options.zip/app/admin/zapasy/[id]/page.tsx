"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Save } from "lucide-react";
import { displayToIsoDate, getStoredMatches, updateMatch } from "@/lib/demo-store";

type MatchFormState = {
  id: string;
  date: string;
  time: string;
  competition: string;
  home: string;
  away: string;
  location: string;
  neededRefs: string;
};

export default function EditZapasPage() {
  const params = useParams<{ id: string }>();
  const [adminName, setAdminName] = useState("Administrátor");
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState<MatchFormState | null>(null);

  const matchId = useMemo(() => String(params?.id ?? ""), [params]);

  useEffect(() => {
    const role = localStorage.getItem("demo-role");
    const storedName = localStorage.getItem("demo-user-name");

    if (!role) {
      window.location.href = "/login";
      return;
    }
    if (role !== "admin") {
      window.location.href = "/zapasy";
      return;
    }
    if (storedName) {
      setAdminName(storedName);
    }

    const found = getStoredMatches().find((item) => String(item.id) === matchId);
    if (found) {
      setForm({
        id: found.id,
        date: displayToIsoDate(found.date),
        time: found.time,
        competition: found.competition,
        home: found.home,
        away: found.away,
        location: found.location,
        neededRefs: String(found.neededRefs),
      });
    }
  }, [matchId]);

  const updateField = (field: keyof MatchFormState, value: string) => {
    setSaved(false);
    setForm((prev) => (prev ? { ...prev, [field]: value } : prev));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form) return;
    updateMatch(form.id, {
      date: form.date.split("-").reverse().join("."),
      time: form.time,
      competition: form.competition,
      home: form.home,
      away: form.away,
      location: form.location,
      neededRefs: Number(form.neededRefs),
    });
    setSaved(true);
  };

  if (!form) {
    return (
      <main className="min-h-screen bg-slate-100 p-4">
        <div className="mx-auto mt-10 max-w-md rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
          <div className="text-lg font-semibold text-slate-900">Zápas nebyl nalezen</div>
          <Link href="/admin" className="mt-4 inline-flex rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Zpět do administrace</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-100 pb-10">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div><div className="text-lg font-bold text-slate-900">Upravit zápas</div><div className="text-sm text-slate-500">{adminName}</div></div>
          <Link href="/admin" className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"><ArrowLeft className="mr-2 h-4 w-4" />Zpět</Link>
        </div>
      </header>
      <div className="mx-auto max-w-md px-4 py-4">
        <form onSubmit={handleSubmit} className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
          <div className="space-y-4">
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Datum</label><input type="date" value={form.date} onChange={(e) => updateField("date", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Čas</label><input type="time" value={form.time} onChange={(e) => updateField("time", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Soutěž</label><input type="text" value={form.competition} onChange={(e) => updateField("competition", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Domácí tým</label><input type="text" value={form.home} onChange={(e) => updateField("home", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Hostující tým</label><input type="text" value={form.away} onChange={(e) => updateField("away", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Místo</label><input type="text" value={form.location} onChange={(e) => updateField("location", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            <div><label className="mb-1 block text-sm font-medium text-slate-700">Počet rozhodčích</label><input type="number" min="1" max="6" value={form.neededRefs} onChange={(e) => updateField("neededRefs", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" /></div>
            {saved ? <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700 ring-1 ring-emerald-200">Změny byly uloženy.</div> : null}
            <button type="submit" className="flex h-12 w-full items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800"><Save className="mr-2 h-4 w-4" />Uložit změny</button>
          </div>
        </form>
      </div>
    </main>
  );
}
