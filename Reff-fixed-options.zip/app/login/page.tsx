"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { LogIn, Shield } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loadingRole, setLoadingRole] = useState<"referee" | "admin" | null>(null);

  const handleLogin = async (role: "referee" | "admin") => {
    setLoadingRole(role);

    try {
      localStorage.setItem("demo-role", role);
      localStorage.setItem(
        "demo-user-name",
        role === "admin" ? "Administrátor" : "Jan Novák"
      );
      localStorage.setItem("demo-identifier", identifier);

      if (role === "admin") {
        router.push("/admin");
      } else {
        router.push("/zapasy");
      }
    } finally {
      setLoadingRole(null);
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-100 via-slate-100 to-slate-200 px-4 py-8">
      <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-md items-center justify-center">
        <div className="w-full rounded-3xl bg-white p-6 shadow-xl ring-1 ring-slate-200">
          <div className="mb-6 flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-900 text-white">
              <Shield className="h-7 w-7" />
            </div>

            <div>
              <h1 className="text-2xl font-bold tracking-tight">Delegace rozhodčích</h1>
              <p className="text-sm text-slate-500">
                Přehledná aplikace pro rozhodčí a administrátory
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label
                htmlFor="identifier"
                className="mb-1 block text-sm font-medium text-slate-700"
              >
                Email nebo telefon
              </label>
              <input
                id="identifier"
                type="text"
                placeholder="např. jan@demo.cz"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                className="h-12 w-full rounded-xl border border-slate-300 bg-white px-4 text-base outline-none transition focus:border-slate-500 focus:ring-2 focus:ring-slate-200"
              />
            </div>

            <div>
              <label
                htmlFor="password"
                className="mb-1 block text-sm font-medium text-slate-700"
              >
                Heslo
              </label>
              <input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 w-full rounded-xl border border-slate-300 bg-white px-4 text-base outline-none transition focus:border-slate-500 focus:ring-2 focus:ring-slate-200"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 pt-2">
              <button
                type="button"
                onClick={() => handleLogin("referee")}
                disabled={loadingRole !== null}
                className="flex h-12 w-full items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <LogIn className="mr-2 h-4 w-4" />
                {loadingRole === "referee"
                  ? "Přihlašování..."
                  : "Přihlásit se jako rozhodčí"}
              </button>

              <button
                type="button"
                onClick={() => handleLogin("admin")}
                disabled={loadingRole !== null}
                className="flex h-12 w-full items-center justify-center rounded-xl border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-900 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <LogIn className="mr-2 h-4 w-4" />
                {loadingRole === "admin"
                  ? "Přihlašování..."
                  : "Přihlásit se jako administrátor"}
              </button>
            </div>

            <div className="pt-2 text-center text-sm text-slate-500">
              Zapomenuté heslo
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}