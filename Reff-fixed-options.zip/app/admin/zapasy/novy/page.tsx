"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Save } from "lucide-react";
import {
  createMatch,
  getReferees,
  initializeDemoStore,
  isoToDisplayDate,
  type DemoUser,
} from "@/lib/demo-store";

type MatchFormState = {
  date: string;
  time: string;
  competition: string;
  home: string;
  away: string;
  location: string;
  neededRefs: string;
};

const initialState: MatchFormState = {
  date: "",
  time: "",
  competition: "",
  home: "",
  away: "",
  location: "",
  neededRefs: "3",
};

function getPositionLabel(index: number) {
  if (index === 0) return "Hlavní rozhodčí";
  return `Asistent ${index}`;
}

export default function NovyZapasPage() {
  const [adminName, setAdminName] = useState("Administrátor");
  const [form, setForm] = useState<MatchFormState>(initialState);
  const [referees, setReferees] = useState<DemoUser[]>([]);
  const [selectedRefs, setSelectedRefs] = useState<string[]>(["", "", ""]);
  const [saved, setSaved] = useState(false);
  const [message, setMessage] = useState("");

  const neededRefsNumber = useMemo(() => {
    const parsed = Number(form.neededRefs);
    if (Number.isNaN(parsed)) return 1;
    return Math.min(Math.max(parsed, 1), 6);
  }, [form.neededRefs]);

  useEffect(() => {
    const role = localStorage.getItem("demo-role");
    const storedName = localStorage.getItem("demo-user-name");

    if (!role) {
      window.location.href = "/login";
      return;
    }
    if (role !== "admin") {
      window.location.href = "/zapasy";
      return;
    }

    initializeDemoStore();
    setReferees(getReferees());

    if (storedName) {
      setAdminName(storedName);
    }
  }, []);

  const updateField = (field: keyof MatchFormState, value: string) => {
    setSaved(false);
    setMessage("");
    setForm((prev) => ({ ...prev, [field]: value }));

    if (field === "neededRefs") {
      const parsed = Number(value);
      const nextCount = Number.isNaN(parsed) ? 1 : Math.min(Math.max(parsed, 1), 6);

      setSelectedRefs((prev) => {
        const next = [...prev];
        while (next.length < nextCount) next.push("");
        return next.slice(0, nextCount);
      });
    }
  };

  const updateSelectedRef = (index: number, value: string) => {
    setSaved(false);
    setMessage("");
    setSelectedRefs((prev) => {
      const next = [...prev];
      next[index] = value;
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedNames = Array.from(new Set(selectedRefs.filter(Boolean)));

    createMatch(
      {
        date: isoToDisplayDate(form.date),
        time: form.time,
        competition: form.competition,
        home: form.home,
        away: form.away,
        location: form.location,
        neededRefs: Number(form.neededRefs),
      },
      selectedNames
    );

    setSaved(true);
    setForm(initialState);
    setSelectedRefs(["", "", ""]);
    setMessage(selectedNames.length > 0 ? "Zápas byl uložen a rozhodčí byli delegováni." : "Zápas byl uložen.");
  };

  return (
    <main className="min-h-screen bg-slate-100 pb-10">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div>
            <div className="text-lg font-bold text-slate-900">Nový zápas</div>
            <div className="text-sm text-slate-500">{adminName}</div>
          </div>
          <Link href="/admin" className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Zpět
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-md px-4 py-4">
        <form onSubmit={handleSubmit} className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Datum</label>
              <input type="date" value={form.date} onChange={(e) => updateField("date", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Čas</label>
              <input type="time" value={form.time} onChange={(e) => updateField("time", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Soutěž</label>
              <input type="text" value={form.competition} onChange={(e) => updateField("competition", e.target.value)} placeholder="např. Krajský přebor" className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Domácí tým</label>
              <input type="text" value={form.home} onChange={(e) => updateField("home", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Hostující tým</label>
              <input type="text" value={form.away} onChange={(e) => updateField("away", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Místo</label>
              <input type="text" value={form.location} onChange={(e) => updateField("location", e.target.value)} placeholder="např. Praha 10" className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">Počet rozhodčích</label>
              <input type="number" min="1" max="6" value={form.neededRefs} onChange={(e) => updateField("neededRefs", e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 px-4 outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200" required />
            </div>

            <section className="rounded-3xl bg-slate-50 p-4 ring-1 ring-slate-200">
              <div className="mb-3">
                <div className="text-base font-bold text-slate-900">Přímá delegace rozhodčích</div>
                <p className="mt-1 text-sm text-slate-500">Nepovinné. Pokud nikoho nevyberete, rozhodčí se mohou přihlásit sami.</p>
              </div>

              <div className="space-y-3">
                {Array.from({ length: neededRefsNumber }).map((_, index) => (
                  <div key={index}>
                    <label className="mb-1 block text-sm font-medium text-slate-700">{getPositionLabel(index)}</label>
                    <select value={selectedRefs[index] || ""} onChange={(e) => updateSelectedRef(index, e.target.value)} className="h-12 w-full rounded-xl border border-slate-300 bg-white px-4 text-base outline-none focus:border-slate-500 focus:ring-2 focus:ring-slate-200">
                      <option value="">Nevybráno</option>
                      {referees.map((referee) => (
                        <option key={referee.id} value={referee.fullName}>
                          {referee.fullName} {referee.email ? `(${referee.email})` : ""}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </section>

            {message || saved ? <div className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700 ring-1 ring-emerald-200">{message || "Zápas byl uložen."}</div> : null}

            <button type="submit" className="flex h-12 w-full items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800">
              <Save className="mr-2 h-4 w-4" />
              Uložit zápas
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
