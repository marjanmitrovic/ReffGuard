"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, CheckCircle2, Clock3, XCircle } from "lucide-react";
import { approveApplication, getApplications, getMatches, initializeDemoStore, rejectApplication, type Application, type Match } from "@/lib/demo-store";

function getStatusLabel(status: Application["status"]) {
  if (status === "sent") return "Odesláno";
  if (status === "approved") return "Schváleno";
  return "Odmítnuto";
}

function getStatusClasses(status: Application["status"]) {
  if (status === "sent") return "bg-amber-100 text-amber-800 ring-amber-200";
  if (status === "approved") return "bg-emerald-100 text-emerald-800 ring-emerald-200";
  return "bg-rose-100 text-rose-800 ring-rose-200";
}

export default function PrihlaskyKZapasuPage() {
  const params = useParams<{ id: string }>();
  const [adminName, setAdminName] = useState("Administrátor");
  const [matches, setMatches] = useState<Match[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);

  const matchId = useMemo(() => String(params?.id ?? ""), [params]);
  const match = useMemo(() => matches.find((item) => item.id === matchId), [matches, matchId]);

  useEffect(() => {
    const role = localStorage.getItem("demo-role");
    const storedName = localStorage.getItem("demo-user-name");

    if (!role) {
      window.location.href = "/login";
      return;
    }
    if (role !== "admin") {
      window.location.href = "/zapasy";
      return;
    }
    if (storedName) {
      setAdminName(storedName);
    }

    initializeDemoStore();
    setMatches(getMatches());
    setApplications(getApplications());
  }, []);

  const filteredApplications = useMemo(() => applications.filter((item) => item.matchId === matchId), [applications, matchId]);
  const approvedCount = filteredApplications.filter((item) => item.status === "approved").length;
  const canApproveMore = match ? approvedCount < match.neededRefs : false;

  const refresh = () => {
    setMatches(getMatches());
    setApplications(getApplications());
  };

  const handleApprove = (id: string) => {
    if (!canApproveMore) return;
    approveApplication(id);
    refresh();
  };

  const handleReject = (id: string) => {
    rejectApplication(id);
    refresh();
  };

  if (!match) {
    return (
      <main className="min-h-screen bg-slate-100 p-4">
        <div className="mx-auto mt-10 max-w-md rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
          <div className="text-lg font-semibold text-slate-900">Zápas nebyl nalezen</div>
          <Link href="/admin" className="mt-4 inline-flex rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Zpět do administrace</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-100 pb-10">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-4">
          <div><div className="text-lg font-bold text-slate-900">Přihlášky k zápasu</div><div className="text-sm text-slate-500">{adminName}</div></div>
          <Link href="/admin" className="flex h-10 items-center justify-center rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition hover:bg-slate-50"><ArrowLeft className="mr-2 h-4 w-4" />Zpět</Link>
        </div>
      </header>

      <div className="mx-auto max-w-md space-y-4 px-4 py-4">
        <section className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
          <div className="text-lg font-bold text-slate-900">{match.home} – {match.away}</div>
          <div className="mt-1 text-sm text-slate-500">{match.competition}</div>
          <div className="mt-3 space-y-1 text-sm text-slate-700">
            <div>{match.date} • {match.time}</div>
            <div>{match.location}</div>
            <div>Schváleno: {approvedCount} / {match.neededRefs}</div>
          </div>
        </section>

        {filteredApplications.length === 0 ? (
          <div className="rounded-3xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
            <div className="text-lg font-semibold text-slate-900">Žádné přihlášky</div>
            <p className="mt-2 text-sm text-slate-500">K tomuto zápasu zatím nejsou žádné přihlášky.</p>
          </div>
        ) : (
          filteredApplications.map((item) => (
            <article key={item.id} className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <div className="text-lg font-bold text-slate-900">{item.refereeName}</div>
                  <div className="mt-1 flex items-center gap-2 text-sm text-slate-500"><Clock3 className="h-4 w-4" />{item.appliedAt}</div>
                </div>
                <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ring-1 ${getStatusClasses(item.status)}`}>{getStatusLabel(item.status)}</span>
              </div>

              {item.status === "sent" ? (
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => handleApprove(item.id)} disabled={!canApproveMore} className="flex h-11 items-center justify-center rounded-xl bg-slate-900 px-3 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-600"><CheckCircle2 className="mr-2 h-4 w-4" />Schválit</button>
                  <button type="button" onClick={() => handleReject(item.id)} className="flex h-11 items-center justify-center rounded-xl border border-rose-300 bg-white px-3 text-sm font-semibold text-rose-700 transition hover:bg-rose-50"><XCircle className="mr-2 h-4 w-4" />Odmítnout</button>
                </div>
              ) : null}
            </article>
          ))
        )}
      </div>
    </main>
  );
}
