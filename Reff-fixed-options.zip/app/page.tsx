"use client";

import { useEffect } from "react";

export default function HomePage() {
  useEffect(() => {
    const role = localStorage.getItem("demo-role");

    if (!role) {
      window.location.href = "/login";
      return;
    }

    if (role === "admin") {
      window.location.href = "/admin";
      return;
    }

    window.location.href = "/zapasy";
  }, []);

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <div className="rounded-3xl bg-white px-6 py-5 text-center shadow-sm ring-1 ring-slate-200">
        <div className="text-lg font-semibold text-slate-900">Načítání aplikace...</div>
        <p className="mt-2 text-sm text-slate-500">Probíhá přesměrování.</p>
      </div>
    </main>
  );
}